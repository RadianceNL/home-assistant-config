import{bW as o}from"./card-f444d6e4.js";function t(t,n){return n="function"==typeof n?n:void 0,t&&t.length?o(t,void 0,n):[]}export{t as u};
